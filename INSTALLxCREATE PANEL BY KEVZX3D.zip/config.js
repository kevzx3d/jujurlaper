module.exports = {
  BOT_TOKEN: "8276348609:AAEa2SzESK3K3krJVpDYzkFv-4s-W2v37jk",
  OWNER_ID: ["8426492827"],
  
  /// NGGAK TAU BUAT APA POKOK NYA BUAT START WINGS🗿🗿
  tokeninstall: "revan",
  bash: "bash <(curl https://raw.githubusercontent.com/zerodevxc/revan/refs/heads/main/install.sh)",
  
  // Domain Reseller Panel 
  domain: 'domainlu', // domain
  plta: 'ptlalu', // pltc reseller 
  pltc: 'ptlclu', // pltc reseller 
  
  // Domain Khusus Admin
  domainv2: 'domainlu', // domain
  pltav2: 'plta_abcdefghij', // plta khusus admin
  pltcv2: 'pltc_abcdefghij', // pltc khusus admin 
  
  loc: '1', // 
  eggs: '15'
};